import React from 'react';

function Login() {
  return (
    <div style={{color: "#fff", textAlign: "center", margin: "2rem auto"}}>
      <h2>Login</h2>
      <p>Login functionality here.</p>
    </div>
  );
}

export default Login;
