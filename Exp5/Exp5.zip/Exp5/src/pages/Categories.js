import React from 'react';

function Categories() {
  return (
    <div style={{color: "#fff", textAlign: "center", margin: "2rem auto"}}>
      <h2>Categories</h2>
      <p>Browse books by category .</p>
    </div>
  );
}

export default Categories;
