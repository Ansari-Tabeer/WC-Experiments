import React from 'react';

function NewArrivals() {
  return (
    <div style={{color: "#fff", textAlign: "center", margin: "2rem auto"}}>
      <h2>New Arrivals</h2>
      <p>Discover new releases every week!</p>
    </div>
  );
}

export default NewArrivals;
