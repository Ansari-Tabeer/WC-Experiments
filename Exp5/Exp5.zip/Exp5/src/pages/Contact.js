import React from 'react';

function Contact() {
  return (
    <div style={{color: "#fff", textAlign: "center", margin: "2rem auto"}}>
      <h2>Contact Us</h2>
      <p>Email: help@onlinebookstore.com</p>
    </div>
  );
}

export default Contact;
