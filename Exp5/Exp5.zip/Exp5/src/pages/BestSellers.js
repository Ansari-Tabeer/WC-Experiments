import React from 'react';

function BestSellers() {
  return (
    <div style={{color: "#fff", textAlign: "center", margin: "2rem auto"}}>
      <h2>Best Sellers</h2>
      <p>See the Best books in our collection!</p>
    </div>
  );
}

export default BestSellers;
